This zip contains an updated set of NHL fonts - some of them will probably be the same as in my old set, but these were made from a new set of source files.

These fonts are for personal use only.

Thanks to Alex Minnehan for the source files!

Any questions?  eriqjaffe@gmail.com

Enjoy!